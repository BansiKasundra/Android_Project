package com.example.safetysquad

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.fragment.app.Fragment
import com.example.safetysquad.databinding.ActivityMainpageBinding
import com.example.safetysquad.FragmentOne
import com.example.safetysquad.FragmentThree
import com.example.safetysquad.FragmentTwo


class Mainpage : AppCompatActivity() {

    lateinit var mBinding: ActivityMainpageBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_mainpage)

        mBinding = ActivityMainpageBinding.inflate(layoutInflater)
        setContentView(mBinding.root)

        replaceFragment(FragmentOne())

        mBinding.btnOneFrag.setOnClickListener {
            replaceFragment(FragmentOne())
        }

        mBinding.btnTwoFrag.setOnClickListener {
            replaceFragment(FragmentTwo())
        }

        mBinding.btnThreeFrag.setOnClickListener {
            replaceFragment(FragmentThree())
        }

        mBinding.btnFourFrag.setOnClickListener {
            replaceFragment(FragmentFour())
        }
    }

    private fun replaceFragment(fragment: Fragment) {
        val fragmentManager = supportFragmentManager
        val fragmentTransaction = fragmentManager.beginTransaction()
        fragmentTransaction.replace(R.id.fragments, fragment)
        fragmentTransaction.commit()
    }

    }
}